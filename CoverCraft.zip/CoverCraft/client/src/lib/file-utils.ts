// Helper function to format file size
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) {
    return bytes + ' B';
  } else if (bytes < 1048576) {
    return (bytes / 1024).toFixed(1) + ' KB';
  } else {
    return (bytes / 1048576).toFixed(1) + ' MB';
  }
}

// Validate if the file type is supported
export function isValidFileType(file: File): boolean {
  const validTypes = [
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain'
  ];
  const fileExtension = file.name.split('.').pop()?.toLowerCase();
  
  return validTypes.includes(file.type) || 
         (fileExtension === 'pdf' || fileExtension === 'docx' || fileExtension === 'txt');
}

// Get file extension from file object
export function getFileExtension(file: File): string {
  return file.name.split('.').pop()?.toLowerCase() || '';
}
