import { ChangeEvent, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { FormData } from "@/pages/Home";

interface JobDescriptionSectionProps {
  formData: FormData;
  updateFormData: (key: keyof FormData, value: string) => void;
}

const JobDescriptionSection = ({ formData, updateFormData }: JobDescriptionSectionProps) => {
  const [charCount, setCharCount] = useState(0);
  const MAX_CHARS = 10000;

  const handleInputChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    updateFormData(name as keyof FormData, value);
    
    if (name === "jobDescription") {
      setCharCount(value.length);
    }
  };

  return (
    <Card className="mb-6 shadow-sm">
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold text-secondary mb-4">Step 2: Enter Job Description</h2>
        
        <div className="mb-4">
          <Label htmlFor="jobTitle" className="mb-2">Job Title</Label>
          <Input 
            id="jobTitle"
            name="jobTitle"
            placeholder="e.g., Software Engineer, Marketing Manager"
            value={formData.jobTitle}
            onChange={handleInputChange}
            className="w-full px-4 py-2 focus:ring-2 focus:ring-primary"
          />
        </div>
        
        <div className="mb-4">
          <Label htmlFor="companyName" className="mb-2">Company Name</Label>
          <Input 
            id="companyName"
            name="companyName"
            placeholder="e.g., Google, Microsoft"
            value={formData.companyName}
            onChange={handleInputChange}
            className="w-full px-4 py-2 focus:ring-2 focus:ring-primary"
          />
        </div>
        
        <div className="mb-2">
          <div className="flex justify-between items-center mb-2">
            <Label htmlFor="jobDescription">Job Description</Label>
            <span className="text-sm text-gray-500">{charCount}/{MAX_CHARS}</span>
          </div>
          <Textarea 
            id="jobDescription"
            name="jobDescription"
            rows={6}
            placeholder="Paste the full job description here. The more details you provide, the better the AI can tailor your cover letter."
            maxLength={MAX_CHARS}
            value={formData.jobDescription}
            onChange={handleInputChange}
            className="w-full px-4 py-2 focus:ring-2 focus:ring-primary"
          />
        </div>
        <p className="text-sm text-gray-500 mb-4">
          Copy and paste the full job posting to help our AI understand the role requirements.
        </p>
      </CardContent>
    </Card>
  );
};

export default JobDescriptionSection;
