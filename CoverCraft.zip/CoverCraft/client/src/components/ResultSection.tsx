import { useState, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Edit, 
  ClipboardCopy, 
  Download, 
  Printer, 
  ThumbsUp, 
  ThumbsDown,
  RefreshCw
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { CoverLetter } from "@/pages/Home";

interface ResultSectionProps {
  coverLetter: CoverLetter;
  jobTitle: string;
  companyName: string;
  onRegenerate: () => void;
}

const ResultSection = ({ coverLetter, jobTitle, companyName, onRegenerate }: ResultSectionProps) => {
  const { toast } = useToast();
  const [editing, setEditing] = useState(false);
  const [content, setContent] = useState(coverLetter.content);
  const contentRef = useRef<HTMLDivElement>(null);
  
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(content);
      toast({
        title: "Success",
        description: "Cover letter copied to clipboard!",
        variant: "default",
        duration: 3000,
      });
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please try again or select and copy manually.",
        variant: "destructive",
      });
    }
  };

  const handleDownload = () => {
    const element = document.createElement("a");
    const file = new Blob([content], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `Cover_Letter_${jobTitle.replace(/\s+/g, "_")}_${companyName.replace(/\s+/g, "_")}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handlePrint = () => {
    const printWindow = window.open("", "_blank");
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Cover Letter - ${jobTitle} at ${companyName}</title>
            <style>
              body {
                font-family: 'Open Sans', Arial, sans-serif;
                line-height: 1.6;
                margin: 1.5cm;
                color: #333;
              }
              @media print {
                body {
                  margin: 1.5cm;
                }
              }
            </style>
          </head>
          <body>
            <div>${content.replace(/\n/g, "<br>")}</div>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.focus();
      printWindow.print();
      printWindow.close();
    }
  };

  const toggleEditing = () => {
    setEditing(!editing);
  };

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
  };

  return (
    <Card className="mb-6 shadow-sm">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-secondary">Your Generated Cover Letter</h2>
          <div className="flex space-x-2">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={toggleEditing} 
              title="Edit Cover Letter"
              className="text-gray-600 hover:text-primary"
            >
              <Edit className="h-5 w-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleCopy} 
              title="Copy to Clipboard"
              className="text-gray-600 hover:text-primary"
            >
              <ClipboardCopy className="h-5 w-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleDownload} 
              title="Download as Document"
              className="text-gray-600 hover:text-primary"
            >
              <Download className="h-5 w-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handlePrint} 
              title="Print Cover Letter"
              className="text-gray-600 hover:text-primary"
            >
              <Printer className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        <div className="cover-letter-content rounded-lg border border-gray-200 p-6 bg-white">
          {editing ? (
            <textarea
              className="w-full h-[500px] border rounded-md p-3 font-sans text-gray-800"
              value={content}
              onChange={handleContentChange}
            />
          ) : (
            <div 
              ref={contentRef} 
              className="whitespace-pre-line"
              style={{ fontFamily: 'Open Sans, sans-serif' }}
            >
              {content}
            </div>
          )}
        </div>
        
        <div className="mt-6">
          <h3 className="font-medium text-secondary mb-3">What did you think of your cover letter?</h3>
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              className="text-gray-700"
            >
              <ThumbsUp className="mr-1 h-4 w-4" /> Great
            </Button>
            <Button 
              variant="outline" 
              className="text-gray-700"
            >
              <ThumbsDown className="mr-1 h-4 w-4" /> Needs Improvement
            </Button>
          </div>
          
          <div className="mt-4">
            <Button 
              variant="link" 
              className="text-primary hover:text-primary/80 font-medium p-0"
              onClick={onRegenerate}
            >
              <RefreshCw className="mr-1 h-4 w-4" /> Regenerate with Different Style
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ResultSection;
