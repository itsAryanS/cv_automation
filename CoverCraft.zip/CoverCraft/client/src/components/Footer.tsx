import { FileText } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-secondary py-6 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <div className="flex items-center">
              <FileText className="h-6 w-6 mr-2" />
              <span className="text-lg font-medium">AI Cover Letter Generator</span>
            </div>
            <p className="text-white text-opacity-80 text-sm mt-1">
              Helping you land your dream job with AI-powered cover letters
            </p>
          </div>
          <div className="flex flex-col md:flex-row md:items-center space-y-3 md:space-y-0 md:space-x-6">
            <a href="#" className="text-white text-opacity-80 hover:text-opacity-100">
              Privacy Policy
            </a>
            <a href="#" className="text-white text-opacity-80 hover:text-opacity-100">
              Terms of Service
            </a>
            <a href="#" className="text-white text-opacity-80 hover:text-opacity-100">
              Contact Us
            </a>
          </div>
        </div>
        <div className="mt-6 text-center md:text-left">
          <p className="text-white text-opacity-60 text-sm">
            © {new Date().getFullYear()} AI Cover Letter Generator. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
