import { FileText } from "lucide-react";

const Header = () => {
  return (
    <header className="bg-white border-b border-gray-200">
      <div className="container mx-auto py-4 px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <FileText className="text-primary h-7 w-7 mr-2" />
            <h1 className="text-xl sm:text-2xl font-semibold text-secondary">
              AI Cover Letter Generator
            </h1>
          </div>
          <a href="#" className="text-primary hover:text-opacity-80 text-sm font-medium">
            Help
          </a>
        </div>
      </div>
    </header>
  );
};

export default Header;
