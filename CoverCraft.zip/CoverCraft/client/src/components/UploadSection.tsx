import { useState, useRef, DragEvent, ChangeEvent } from "react";
import { Upload, X, AlertCircle, FileText } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { formatFileSize, isValidFileType } from "@/lib/file-utils";
import { ResumeFile } from "@/pages/Home";

interface UploadSectionProps {
  resumeFile: ResumeFile | null;
  onFileUpload: (file: File) => void;
  onRemoveFile: () => void;
}

const UploadSection = ({ resumeFile, onFileUpload, onRemoveFile }: UploadSectionProps) => {
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files.length > 0) {
      handleFile(e.target.files[0]);
    }
  };

  const handleButtonClick = () => {
    if (inputRef.current) {
      inputRef.current.click();
    }
  };

  const handleFile = (file: File) => {
    setError(null);
    
    if (!isValidFileType(file)) {
      setError("Please upload a PDF, DOCX, or TXT file.");
      return;
    }
    
    onFileUpload(file);
  };

  return (
    <Card className="mb-6 shadow-sm">
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold text-secondary mb-4">Step 1: Upload Your Resume</h2>
        
        {!resumeFile ? (
          <div 
            className={`file-upload-area rounded-lg p-8 mb-4 text-center cursor-pointer ${
              dragActive ? "drag-active" : ""
            }`}
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
          >
            <input 
              ref={inputRef}
              type="file" 
              className="hidden" 
              accept=".pdf,.docx,.txt"
              onChange={handleChange}
            />
            <Upload className="h-10 w-10 text-primary mb-3 mx-auto" />
            <h3 className="text-lg font-medium text-secondary mb-1">Drag & Drop Your Resume</h3>
            <p className="text-gray-500 mb-3">Supported formats: PDF, DOCX, TXT</p>
            <Button
              variant="outline" 
              onClick={handleButtonClick}
              className="bg-white text-primary border border-primary hover:bg-primary hover:text-white"
            >
              Browse Files
            </Button>
          </div>
        ) : (
          <div className="rounded-lg border border-gray-200 p-4 mb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <FileText className="text-primary h-5 w-5 mr-2" />
                <div>
                  <span className="font-medium text-secondary">{resumeFile.file.name}</span>
                  <span className="text-sm text-gray-500 ml-2">{formatFileSize(resumeFile.file.size)}</span>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={onRemoveFile} 
                className="text-gray-400 hover:text-destructive"
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
          </div>
        )}

        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
};

export default UploadSection;
