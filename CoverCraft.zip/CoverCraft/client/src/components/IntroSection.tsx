import { Card, CardContent } from "@/components/ui/card";

const IntroSection = () => {
  return (
    <Card className="mb-6 shadow-sm">
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold text-secondary mb-4">
          Generate Professional Cover Letters Instantly
        </h2>
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="flex-1">
            <p className="text-gray-600 mb-4">
              Our AI-powered tool analyzes your resume and the job description to create a 
              personalized cover letter that highlights your relevant skills and experience.
            </p>
            <ul className="text-gray-600 list-disc list-inside space-y-1">
              <li>Upload your resume (PDF, DOCX, or TXT format)</li>
              <li>Enter the job description</li>
              <li>Get a tailored cover letter in seconds</li>
              <li>Edit, copy, or download your cover letter</li>
            </ul>
          </div>
          <div className="w-full md:w-1/3">
            <img 
              src="https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d" 
              alt="Professional workspace with laptop and documents" 
              className="rounded-lg shadow w-full h-auto" 
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default IntroSection;
