import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, XCircle } from "lucide-react";

const ResourcesSection = () => {
  return (
    <Card className="mb-6 shadow-sm">
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold text-secondary mb-4">Tips for Using Your Cover Letter</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium text-secondary mb-2">Best Practices</h3>
            <ul className="text-gray-600 space-y-2">
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-[#28A745] mr-2 mt-1 flex-shrink-0" />
                <span>Customize each cover letter for the specific job</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-[#28A745] mr-2 mt-1 flex-shrink-0" />
                <span>Keep your cover letter to one page</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-[#28A745] mr-2 mt-1 flex-shrink-0" />
                <span>Proofread for grammar and spelling errors</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-[#28A745] mr-2 mt-1 flex-shrink-0" />
                <span>Highlight achievements rather than just duties</span>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-medium text-secondary mb-2">What to Avoid</h3>
            <ul className="text-gray-600 space-y-2">
              <li className="flex items-start">
                <XCircle className="h-5 w-5 text-[#DC3545] mr-2 mt-1 flex-shrink-0" />
                <span>Generic cover letters not tailored to the job</span>
              </li>
              <li className="flex items-start">
                <XCircle className="h-5 w-5 text-[#DC3545] mr-2 mt-1 flex-shrink-0" />
                <span>Including irrelevant personal information</span>
              </li>
              <li className="flex items-start">
                <XCircle className="h-5 w-5 text-[#DC3545] mr-2 mt-1 flex-shrink-0" />
                <span>Repeating your entire resume in the letter</span>
              </li>
              <li className="flex items-start">
                <XCircle className="h-5 w-5 text-[#DC3545] mr-2 mt-1 flex-shrink-0" />
                <span>Using overly complex language or jargon</span>
              </li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ResourcesSection;
