import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Wand2, Loader2, AlertCircle, RefreshCw } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { FormData } from "@/pages/Home";

interface GenerateSectionProps {
  formData: FormData;
  updateFormData: (key: keyof FormData, value: string) => void;
  onGenerate: () => void;
  isGenerating: boolean;
  generationError: string | null;
  progress: number;
  onTryAgain: () => void;
}

const GenerateSection = ({
  formData,
  updateFormData,
  onGenerate,
  isGenerating,
  generationError,
  progress,
  onTryAgain
}: GenerateSectionProps) => {
  
  const handleSelectChange = (key: keyof FormData, value: string) => {
    updateFormData(key, value);
  };

  return (
    <Card className="mb-6 shadow-sm">
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold text-secondary mb-4">Step 3: Generate Your Cover Letter</h2>
        
        <div className="mb-6">
          <p className="text-gray-600 mb-4">
            Our AI will analyze your resume and the job description to create a personalized cover letter 
            highlighting your relevant qualifications and experience.
          </p>
          
          {!isGenerating && !generationError && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <Label className="mb-2">Tone</Label>
                  <Select 
                    value={formData.tone} 
                    onValueChange={(value) => handleSelectChange("tone", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select tone" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="professional">Professional</SelectItem>
                      <SelectItem value="enthusiastic">Enthusiastic</SelectItem>
                      <SelectItem value="confident">Confident</SelectItem>
                      <SelectItem value="formal">Formal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="mb-2">Length</Label>
                  <Select 
                    value={formData.length} 
                    onValueChange={(value) => handleSelectChange("length", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select length" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="concise">Concise (250-350 words)</SelectItem>
                      <SelectItem value="standard">Standard (350-450 words)</SelectItem>
                      <SelectItem value="detailed">Detailed (450-550 words)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Button 
                onClick={onGenerate}
                className="w-full bg-primary text-white hover:bg-primary/90 px-6 py-3 rounded-lg font-medium text-lg"
                size="lg"
              >
                <Wand2 className="mr-2 h-5 w-5" />
                Generate Cover Letter
              </Button>
            </>
          )}
        </div>
        
        {isGenerating && (
          <div className="mb-6">
            <div className="bg-gray-100 rounded-lg p-6 text-center">
              <div className="inline-block mb-4">
                <Loader2 className="h-10 w-10 text-primary animate-spin" />
              </div>
              <h3 className="text-lg font-medium text-secondary mb-2">Generating Your Cover Letter</h3>
              <p className="text-gray-600 mb-4">Our AI is analyzing your resume and the job description...</p>
              <Progress value={progress} className="h-2.5 mb-1" />
              <p className="text-xs text-gray-500">This may take up to 30 seconds</p>
            </div>
          </div>
        )}
        
        {generationError && (
          <div className="mb-6">
            <Alert variant="destructive">
              <AlertCircle className="h-5 w-5" />
              <AlertTitle className="font-medium text-lg">Generation Failed</AlertTitle>
              <AlertDescription className="mb-3">
                {generationError}
              </AlertDescription>
              <Button 
                variant="outline" 
                className="bg-white text-destructive border-destructive hover:bg-destructive hover:text-white"
                onClick={onTryAgain}
              >
                <RefreshCw className="mr-2 h-4 w-4" /> Try Again
              </Button>
            </Alert>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default GenerateSection;
