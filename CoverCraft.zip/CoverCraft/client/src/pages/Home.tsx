import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import IntroSection from "@/components/IntroSection";
import UploadSection from "@/components/UploadSection";
import JobDescriptionSection from "@/components/JobDescriptionSection";
import GenerateSection from "@/components/GenerateSection";
import ResultSection from "@/components/ResultSection";
import ResourcesSection from "@/components/ResourcesSection";
import { useToast } from "@/hooks/use-toast";

export interface ResumeFile {
  file: File;
  preview: string;
}

export interface FormData {
  jobTitle: string;
  companyName: string;
  jobDescription: string;
  tone: "professional" | "enthusiastic" | "confident" | "formal";
  length: "concise" | "standard" | "detailed";
}

export interface CoverLetter {
  content: string;
  metadata: {
    timestamp: string;
  };
}

const Home = () => {
  const { toast } = useToast();
  const [resumeFile, setResumeFile] = useState<ResumeFile | null>(null);
  const [formData, setFormData] = useState<FormData>({
    jobTitle: "",
    companyName: "",
    jobDescription: "",
    tone: "professional",
    length: "standard",
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationError, setGenerationError] = useState<string | null>(null);
  const [coverLetter, setCoverLetter] = useState<CoverLetter | null>(null);
  const [progress, setProgress] = useState(0);

  const handleFileUpload = (file: File) => {
    setResumeFile({
      file,
      preview: URL.createObjectURL(file),
    });
  };

  const removeFile = () => {
    if (resumeFile?.preview) {
      URL.revokeObjectURL(resumeFile.preview);
    }
    setResumeFile(null);
  };

  const updateFormData = (key: keyof FormData, value: string) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };

  const handleGenerateCoverLetter = async () => {
    // Validate form
    if (!resumeFile) {
      toast({
        title: "Missing resume",
        description: "Please upload your resume first.",
        variant: "destructive",
      });
      return;
    }

    if (!formData.jobDescription.trim()) {
      toast({
        title: "Missing job description",
        description: "Please enter the job description.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    setGenerationError(null);
    setProgress(0);

    // Create progress simulation
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + Math.random() * 10;
        return newProgress > 90 ? 90 : newProgress;
      });
    }, 500);

    try {
      // Create form data for file upload
      const data = new FormData();
      data.append("resume", resumeFile.file);
      data.append("jobTitle", formData.jobTitle);
      data.append("companyName", formData.companyName);
      data.append("jobDescription", formData.jobDescription);
      data.append("tone", formData.tone);
      data.append("length", formData.length);

      // Send request to backend
      const response = await fetch("/api/generate-cover-letter", {
        method: "POST",
        body: data,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to generate cover letter");
      }

      const result = await response.json();
      
      // Complete progress
      clearInterval(progressInterval);
      setProgress(100);

      // Set the result
      setTimeout(() => {
        setCoverLetter(result);
        setIsGenerating(false);
      }, 500);
    } catch (error) {
      clearInterval(progressInterval);
      setIsGenerating(false);
      setGenerationError(error instanceof Error ? error.message : "An unknown error occurred");
      toast({
        title: "Generation failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    }
  };

  const handleRegenerate = () => {
    setCoverLetter(null);
    setGenerationError(null);
    handleGenerateCoverLetter();
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <IntroSection />
          <UploadSection 
            resumeFile={resumeFile} 
            onFileUpload={handleFileUpload} 
            onRemoveFile={removeFile} 
          />
          <JobDescriptionSection 
            formData={formData} 
            updateFormData={updateFormData} 
          />
          <GenerateSection 
            formData={formData}
            updateFormData={updateFormData}
            onGenerate={handleGenerateCoverLetter}
            isGenerating={isGenerating}
            generationError={generationError}
            progress={progress}
            onTryAgain={handleGenerateCoverLetter}
          />
          {coverLetter && (
            <ResultSection
              coverLetter={coverLetter}
              jobTitle={formData.jobTitle}
              companyName={formData.companyName}
              onRegenerate={handleRegenerate}
            />
          )}
          <ResourcesSection />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Home;
