import { type Resume, type InsertResume, type CoverLetter, type InsertCoverLetter } from "@shared/schema";

// Storage interface
export interface IStorage {
  getResume(id: number): Promise<Resume | undefined>;
  createResume(resume: InsertResume): Promise<Resume>;
  getCoverLetter(id: number): Promise<CoverLetter | undefined>;
  createCoverLetter(coverLetter: InsertCoverLetter): Promise<CoverLetter>;
  getCoverLettersByResumeId(resumeId: number): Promise<CoverLetter[]>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private resumes: Map<number, Resume>;
  private coverLetters: Map<number, CoverLetter>;
  private resumeId: number;
  private coverLetterId: number;

  constructor() {
    this.resumes = new Map();
    this.coverLetters = new Map();
    this.resumeId = 1;
    this.coverLetterId = 1;
  }

  async getResume(id: number): Promise<Resume | undefined> {
    return this.resumes.get(id);
  }

  async createResume(resume: InsertResume): Promise<Resume> {
    const id = this.resumeId++;
    const newResume: Resume = {
      ...resume,
      id,
      createdAt: new Date(),
    };
    this.resumes.set(id, newResume);
    return newResume;
  }

  async getCoverLetter(id: number): Promise<CoverLetter | undefined> {
    return this.coverLetters.get(id);
  }

  async createCoverLetter(coverLetter: InsertCoverLetter): Promise<CoverLetter> {
    const id = this.coverLetterId++;
    const newCoverLetter: CoverLetter = {
      ...coverLetter,
      id,
      createdAt: new Date(),
    };
    this.coverLetters.set(id, newCoverLetter);
    return newCoverLetter;
  }

  async getCoverLettersByResumeId(resumeId: number): Promise<CoverLetter[]> {
    return Array.from(this.coverLetters.values()).filter(
      (cl) => cl.resumeId === resumeId
    );
  }
}

// Create and export an instance of the storage
export const storage = new MemStorage();
