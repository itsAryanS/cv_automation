import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import { fileProcessor } from "./file-processor";
import { generateCoverLetter } from "./ai-service";
import path from "path";
import { ZodError } from "zod";
import { generateCoverLetterSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure multer for file uploads
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: 10 * 1024 * 1024, // 10MB max file size
    },
    fileFilter: (_req, file, cb) => {
      const filetypes = /pdf|docx|txt/;
      const mimetype = filetypes.test(file.mimetype);
      const extname = filetypes.test(
        path.extname(file.originalname).toLowerCase()
      );

      if (mimetype && extname) {
        return cb(null, true);
      }
      cb(
        new Error(
          "Error: File upload only supports PDF, DOCX, and TXT files!"
        )
      );
    },
  });

  // API endpoint to process resume and generate cover letter
  app.post(
    "/api/generate-cover-letter",
    upload.single("resume"),
    async (req, res) => {
      try {
        if (!req.file) {
          return res.status(400).json({ message: "No resume file uploaded" });
        }

        // Get form data
        const jobTitle = req.body.jobTitle || "";
        const companyName = req.body.companyName || "";
        const jobDescription = req.body.jobDescription;
        const tone = req.body.tone || "professional";
        const length = req.body.length || "standard";

        // Validate job description
        if (!jobDescription || jobDescription.trim() === "") {
          return res.status(400).json({ message: "Job description is required" });
        }

        // Process the resume file to extract text
        const fileData = await fileProcessor.extractText(req.file);

        // Store the processed resume
        const resume = await storage.createResume({
          originalFilename: req.file.originalname,
          fileType: path.extname(req.file.originalname).toLowerCase().substring(1),
          extractedText: fileData,
        });

        // Generate cover letter with AI service
        const coverLetterData = await generateCoverLetter({
          resumeText: fileData,
          jobTitle,
          companyName,
          jobDescription,
          tone,
          length,
        });

        // Store the generated cover letter
        const coverLetter = await storage.createCoverLetter({
          resumeId: resume.id,
          jobTitle,
          companyName,
          jobDescription,
          tone,
          length,
          content: coverLetterData,
        });

        // Return the result
        return res.status(200).json({
          content: coverLetterData,
          metadata: {
            timestamp: new Date().toISOString(),
          },
        });
      } catch (error) {
        console.error("Error generating cover letter:", error);
        if (error instanceof ZodError) {
          return res.status(400).json({
            message: "Validation error",
            errors: error.errors,
          });
        }
        
        return res.status(500).json({
          message: error instanceof Error ? error.message : "An error occurred during cover letter generation",
        });
      }
    }
  );

  const httpServer = createServer(app);
  return httpServer;
}
