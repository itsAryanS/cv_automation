import { Express } from "express";
import pdfParse from "pdf-parse";
import mammoth from "mammoth";

// Interface for file processing utilities
interface FileProcessor {
  extractText(file: Express.Multer.File): Promise<string>;
}

// Implementation for file processing
class FileProcessorImpl implements FileProcessor {
  /**
   * Extract text from uploaded resume files (PDF, DOCX, TXT)
   */
  async extractText(file: Express.Multer.File): Promise<string> {
    const fileExtension = file.originalname.split('.').pop()?.toLowerCase();
    
    try {
      switch (fileExtension) {
        case 'pdf':
          return await this.extractPdfText(file.buffer);
        case 'docx':
          return await this.extractDocxText(file.buffer);
        case 'txt':
          return this.extractTxtText(file.buffer);
        default:
          throw new Error(`Unsupported file type: ${fileExtension}`);
      }
    } catch (error) {
      console.error(`Error extracting text from ${fileExtension} file:`, error);
      throw new Error(`Failed to extract text from ${fileExtension} file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Extract text from PDF files
   */
  private async extractPdfText(buffer: Buffer): Promise<string> {
    try {
      const data = await pdfParse(buffer);
      return data.text || '';
    } catch (error) {
      console.error('Error parsing PDF:', error);
      throw new Error('Failed to parse PDF file');
    }
  }

  /**
   * Extract text from DOCX files
   */
  private async extractDocxText(buffer: Buffer): Promise<string> {
    try {
      const result = await mammoth.extractRawText({ buffer });
      return result.value || '';
    } catch (error) {
      console.error('Error parsing DOCX:', error);
      throw new Error('Failed to parse DOCX file');
    }
  }

  /**
   * Extract text from TXT files
   */
  private extractTxtText(buffer: Buffer): string {
    try {
      return buffer.toString('utf8');
    } catch (error) {
      console.error('Error parsing TXT:', error);
      throw new Error('Failed to parse TXT file');
    }
  }
}

// Create and export a singleton instance
export const fileProcessor = new FileProcessorImpl();
