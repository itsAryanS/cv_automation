import axios from 'axios';

interface CoverLetterRequest {
  resumeText: string;
  jobTitle: string;
  companyName: string;
  jobDescription: string;
  tone: string;
  length: string;
}

/**
 * Generate a cover letter using AI service based on resume and job description
 */
export async function generateCoverLetter(
  request: CoverLetterRequest
): Promise<string> {
  const { resumeText, jobTitle, companyName, jobDescription, tone, length } = request;
  
  try {
    // Check if API key exists in environment variables
    const apiKey = process.env.AI_API_KEY || process.env.OPENAI_API_KEY;
    const apiUrl = process.env.AI_API_URL || 'https://api.openai.com/v1/chat/completions';
    
    if (!apiKey) {
      console.warn('AI API key not found in environment variables, using mock response');
      return generateMockCoverLetter(request);
    }

    // Prepare AI API request
    const lengthMap = {
      'concise': 'brief and to the point (250-350 words)',
      'standard': 'balanced with good detail (350-450 words)',
      'detailed': 'comprehensive with examples (450-550 words)'
    };

    const toneDescription = {
      'professional': 'formal and businesslike',
      'enthusiastic': 'energetic and passionate',
      'confident': 'assured and authoritative',
      'formal': 'very formal and traditional'
    };

    // Create prompt for AI model
    const prompt = `
Generate a ${lengthMap[length as keyof typeof lengthMap]} cover letter with a ${toneDescription[tone as keyof typeof toneDescription]} tone.

Use the following resume information:
${resumeText}

For the following job:
${jobTitle ? `Job Title: ${jobTitle}` : ''}
${companyName ? `Company: ${companyName}` : ''}
Job Description:
${jobDescription}

The cover letter should follow a professional format with date, address, salutation, and signature.
It should highlight relevant experience and skills from the resume that match the job requirements.
Do not invent or fabricate any qualifications or experience not mentioned in the resume.
Format the cover letter with proper spacing and paragraph breaks.
`;

    // Make request to AI API
    const response = await axios.post(
      apiUrl,
      {
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: 'You are a professional cover letter writer with expertise in career services and recruiting.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 1500
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        }
      }
    );

    // Parse and return the AI-generated cover letter
    if (response.data.choices && response.data.choices.length > 0) {
      const content = response.data.choices[0].message.content;
      return content.trim();
    } else {
      throw new Error('No content returned from AI service');
    }
  } catch (error) {
    console.error('Error calling AI service:', error);
    if (axios.isAxiosError(error)) {
      if (error.response) {
        throw new Error(`AI API error: ${error.response.status} - ${JSON.stringify(error.response.data)}`);
      } else if (error.request) {
        throw new Error('No response received from AI service. Please check your internet connection and try again.');
      }
    }
    throw new Error('Failed to generate cover letter: ' + (error instanceof Error ? error.message : 'Unknown error'));
  }
}

/**
 * Generate a mock cover letter when AI API is not available
 * This is only used for development or when API key is missing
 */
function generateMockCoverLetter(request: CoverLetterRequest): string {
  const { jobTitle, companyName } = request;
  const title = jobTitle || 'the position';
  const company = companyName || 'your company';
  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return `${currentDate}

Dear Hiring Manager,

I am writing to express my interest in ${title} at ${company}. With my background and experience, I am confident that I would be a valuable addition to your team.

After reviewing the job description, I believe my skills and qualifications align well with what you are seeking. Throughout my career, I have developed expertise in relevant areas and have consistently delivered results.

I am particularly drawn to ${company} because of your reputation for innovation and excellence. I am excited about the opportunity to contribute to your team and help achieve your goals.

In addition to my technical skills, I bring strong communication abilities and a collaborative mindset. I thrive in environments that value continuous learning and creative problem-solving.

I would welcome the opportunity to discuss how my background, skills, and enthusiasm can contribute to the continued success of ${company}. Thank you for considering my application.

Sincerely,
[Your Name]`;
}
