import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define the Resume schema
export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  originalFilename: text("original_filename").notNull(),
  fileType: text("file_type").notNull(),
  extractedText: text("extracted_text").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Define the CoverLetter schema
export const coverLetters = pgTable("cover_letters", {
  id: serial("id").primaryKey(),
  resumeId: integer("resume_id").references(() => resumes.id),
  jobTitle: text("job_title"),
  companyName: text("company_name"),
  jobDescription: text("job_description").notNull(),
  tone: text("tone").notNull(),
  length: text("length").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertResumeSchema = createInsertSchema(resumes).omit({
  id: true,
  createdAt: true
});

export const insertCoverLetterSchema = createInsertSchema(coverLetters).omit({
  id: true,
  createdAt: true
});

// API request validation schemas
export const generateCoverLetterSchema = z.object({
  resumeId: z.number(),
  jobTitle: z.string().optional(),
  companyName: z.string().optional(),
  jobDescription: z.string().min(1, "Job description is required"),
  tone: z.enum(["professional", "enthusiastic", "confident", "formal"]),
  length: z.enum(["concise", "standard", "detailed"]),
});

// Types
export type Resume = typeof resumes.$inferSelect;
export type InsertResume = z.infer<typeof insertResumeSchema>;

export type CoverLetter = typeof coverLetters.$inferSelect;
export type InsertCoverLetter = z.infer<typeof insertCoverLetterSchema>;

export type GenerateCoverLetterRequest = z.infer<typeof generateCoverLetterSchema>;
